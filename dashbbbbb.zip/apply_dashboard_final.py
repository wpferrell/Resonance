# Run from C:\Users\Shadow\Documents\Resonance with .venv active
# python apply_dashboard_final.py

import shutil
from pathlib import Path

# Copy dashboard_final.py to both locations
src = Path('dashboard_final.py')
if not src.exists():
    print('ERROR: dashboard_final.py not found in current folder')
    exit(1)

dest1 = Path('resonance/dashboard.py')
dest2 = Path(r'C:\Users\Shadow\resonance\Lib\site-packages\resonance\dashboard.py')

shutil.copy(src, dest1)
print(f'Copied to: {dest1}')

shutil.copy(src, dest2)
print(f'Copied to: {dest2}')

print('Done. Both locations updated with clean silent dashboard.')
